"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DollarSign, TrendingUp } from "lucide-react"

export default function CommissionsPage() {
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Commission Management</h1>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Commission Rate</p>
                <p className="text-3xl font-bold">10%</p>
              </div>
              <DollarSign className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Commission Collected</p>
                <p className="text-3xl font-bold text-accent">₵23,456</p>
              </div>
              <TrendingUp className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div>
              <p className="text-muted-foreground text-sm">This Month</p>
              <p className="text-3xl font-bold">₵4,230</p>
              <p className="text-xs text-green-600 mt-2">+15% from last month</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div>
              <p className="text-muted-foreground text-sm">Transactions Count</p>
              <p className="text-3xl font-bold">12,540</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Commission History</CardTitle>
          <CardDescription>Recent commission transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { order: 5001, seller: "TechHub", amount: 299.99, commission: 30.0, date: "2025-12-02" },
              { order: 5002, seller: "FashionFirst", amount: 149.99, commission: 15.0, date: "2025-12-01" },
              { order: 5003, seller: "HomeStore", amount: 45.5, commission: 4.55, date: "2025-11-30" },
            ].map((item, idx) => (
              <div key={idx} className="flex items-center justify-between pb-4 border-b border-border last:border-0">
                <div>
                  <p className="font-medium">Order #{item.order}</p>
                  <p className="text-sm text-muted-foreground">
                    {item.seller} - {item.date}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-accent">₵{item.commission}</p>
                  <p className="text-xs text-muted-foreground">10% of ₵{item.amount}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
