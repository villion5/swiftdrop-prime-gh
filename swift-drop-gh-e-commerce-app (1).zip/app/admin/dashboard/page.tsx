"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Package, ShoppingCart, DollarSign, TrendingUp, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function MainAdminDashboard() {
  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary to-secondary text-primary-foreground p-8 rounded-lg">
        <h1 className="text-4xl font-bold mb-2">Admin Dashboard</h1>
        <p className="text-primary-foreground/80">Platform overview and management controls</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Users</p>
                <p className="text-3xl font-bold">2,847</p>
              </div>
              <Users className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Active Sellers</p>
                <p className="text-3xl font-bold">342</p>
              </div>
              <Package className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Orders</p>
                <p className="text-3xl font-bold">12,540</p>
              </div>
              <ShoppingCart className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Revenue</p>
                <p className="text-3xl font-bold text-accent">₵234,560</p>
              </div>
              <DollarSign className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Commission Earned</p>
                <p className="text-3xl font-bold text-accent">₵23,456</p>
              </div>
              <TrendingUp className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Platform Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
            <CardDescription>Latest transactions on platform</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1, 2, 3, 4].map((order) => (
                <div
                  key={order}
                  className="flex items-center justify-between pb-4 border-b border-border last:border-0"
                >
                  <div>
                    <p className="font-medium">Order #{5000 + order}</p>
                    <p className="text-xs text-muted-foreground">Today at {10 + order}:30 AM</p>
                  </div>
                  <p className="font-bold text-accent">₵{(Math.random() * 500).toFixed(2)}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Platform Status */}
        <Card>
          <CardHeader>
            <CardTitle>System Status</CardTitle>
            <CardDescription>Platform health check</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-medium">Database</span>
              <div className="flex items-center gap-2 text-green-600">
                <div className="w-3 h-3 bg-green-600 rounded-full" />
                <span className="text-sm">Operational</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-medium">API Server</span>
              <div className="flex items-center gap-2 text-green-600">
                <div className="w-3 h-3 bg-green-600 rounded-full" />
                <span className="text-sm">Operational</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-medium">Payment Gateway</span>
              <div className="flex items-center gap-2 text-green-600">
                <div className="w-3 h-3 bg-green-600 rounded-full" />
                <span className="text-sm">Operational</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-medium">Email Service</span>
              <div className="flex items-center gap-2 text-green-600">
                <div className="w-3 h-3 bg-green-600 rounded-full" />
                <span className="text-sm">Operational</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts */}
      <Card className="border-yellow-200 bg-yellow-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-yellow-800">
            <AlertCircle className="w-5 h-5" />
            Pending Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-sm">12 products pending approval</p>
              <Button size="sm" className="bg-accent hover:bg-accent/90 text-accent-foreground">
                Review
              </Button>
            </div>
            <div className="flex items-center justify-between">
              <p className="text-sm">5 seller verification requests</p>
              <Button size="sm" className="bg-accent hover:bg-accent/90 text-accent-foreground">
                Review
              </Button>
            </div>
            <div className="flex items-center justify-between">
              <p className="text-sm">3 dispute claims open</p>
              <Button size="sm" className="bg-accent hover:bg-accent/90 text-accent-foreground">
                Review
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
