"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search } from "lucide-react"

export default function AdminOrdersPage() {
  const orders = [
    {
      id: 5001,
      buyer: "John Doe",
      seller: "TechHub",
      product: "Wireless Headphones",
      amount: 299.99,
      date: "2025-12-02",
      status: "processing",
    },
    {
      id: 5002,
      buyer: "Jane Smith",
      seller: "FashionFirst",
      product: "Winter Jacket",
      amount: 149.99,
      date: "2025-12-01",
      status: "shipped",
    },
    {
      id: 5003,
      buyer: "Bob Wilson",
      seller: "HomeStore",
      product: "LED Lamp",
      amount: 45.5,
      date: "2025-11-30",
      status: "delivered",
    },
    {
      id: 5004,
      buyer: "Alice Brown",
      seller: "TechHub",
      product: "USB Hub",
      amount: 79.99,
      date: "2025-11-28",
      status: "pending",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "processing":
        return "bg-blue-100 text-blue-800"
      case "shipped":
        return "bg-purple-100 text-purple-800"
      case "delivered":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Order Management</h1>
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
            <Input placeholder="Search orders..." className="pl-10 w-64" />
          </div>
        </div>
      </div>

      {/* Orders Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Orders</CardTitle>
          <CardDescription>Platform-wide order management and tracking</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold">Order ID</th>
                  <th className="text-left py-3 px-4 font-semibold">Buyer</th>
                  <th className="text-left py-3 px-4 font-semibold">Seller</th>
                  <th className="text-left py-3 px-4 font-semibold">Product</th>
                  <th className="text-left py-3 px-4 font-semibold">Amount</th>
                  <th className="text-left py-3 px-4 font-semibold">Date</th>
                  <th className="text-left py-3 px-4 font-semibold">Status</th>
                  <th className="text-left py-3 px-4 font-semibold">Action</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id} className="border-b border-border hover:bg-muted/50">
                    <td className="py-3 px-4 font-bold">#{order.id}</td>
                    <td className="py-3 px-4">{order.buyer}</td>
                    <td className="py-3 px-4">{order.seller}</td>
                    <td className="py-3 px-4">{order.product}</td>
                    <td className="py-3 px-4 font-bold text-accent">₵{order.amount}</td>
                    <td className="py-3 px-4 text-sm">{order.date}</td>
                    <td className="py-3 px-4">
                      <Badge className={getStatusColor(order.status)}>
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      <Button size="sm" className="bg-accent hover:bg-accent/90 text-accent-foreground text-xs">
                        Details
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
