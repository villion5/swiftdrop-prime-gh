"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Package } from "lucide-react"

export default function ProductsManagementPage() {
  const products = [
    { id: 1, name: "Wireless Headphones", seller: "TechHub", price: 299.99, status: "approved", views: 1240 },
    { id: 2, name: "Winter Jacket", seller: "FashionFirst", price: 149.99, status: "approved", views: 840 },
    { id: 3, name: "USB Cable", seller: "TechHub", price: 19.99, status: "pending", views: 0 },
  ]

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Product Management</h1>
        <div className="relative w-64">
          <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
          <Input placeholder="Search products..." className="pl-10" />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Products</CardTitle>
          <CardDescription>Review and manage product listings</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold">Product</th>
                  <th className="text-left py-3 px-4 font-semibold">Seller</th>
                  <th className="text-left py-3 px-4 font-semibold">Price</th>
                  <th className="text-left py-3 px-4 font-semibold">Views</th>
                  <th className="text-left py-3 px-4 font-semibold">Status</th>
                  <th className="text-left py-3 px-4 font-semibold">Action</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => (
                  <tr key={product.id} className="border-b border-border hover:bg-muted/50">
                    <td className="py-3 px-4 font-medium flex items-center gap-2">
                      <Package className="w-4 h-4" /> {product.name}
                    </td>
                    <td className="py-3 px-4 text-sm">{product.seller}</td>
                    <td className="py-3 px-4 font-bold text-accent">₵{product.price}</td>
                    <td className="py-3 px-4">{product.views}</td>
                    <td className="py-3 px-4">
                      <Badge
                        className={
                          product.status === "approved"
                            ? "bg-green-100 text-green-800"
                            : "bg-yellow-100 text-yellow-800"
                        }
                      >
                        {product.status}
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      <Button size="sm" className="bg-accent hover:bg-accent/90 text-accent-foreground text-xs">
                        Review
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
