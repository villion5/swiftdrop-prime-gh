"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"

export default function AdminSettingsPage() {
  return (
    <div className="p-6 space-y-6 max-w-3xl">
      <h1 className="text-3xl font-bold">Platform Settings</h1>

      <Card>
        <CardHeader>
          <CardTitle>Commission Settings</CardTitle>
          <CardDescription>Configure platform commission rates</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="commissionRate">Commission Rate (%)</Label>
            <Input id="commissionRate" type="number" placeholder="10" min="0" max="100" defaultValue="10" />
          </div>
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">Save Commission Settings</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Platform Features</CardTitle>
          <CardDescription>Enable or disable features</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Allow New Seller Registration</Label>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <Label>Allow New Buyer Registration</Label>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <Label>Enable Escrow System</Label>
            <Switch defaultChecked />
          </div>
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">Save Features</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Email Configuration</CardTitle>
          <CardDescription>Manage email notifications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="fromEmail">From Email Address</Label>
            <Input id="fromEmail" type="email" placeholder="noreply@swiftdropgh.com" />
          </div>
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">Save Email Settings</Button>
        </CardContent>
      </Card>
    </div>
  )
}
