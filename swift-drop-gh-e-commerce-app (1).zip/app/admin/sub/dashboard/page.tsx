"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Package, DollarSign, CheckCircle } from "lucide-react"

export default function SubAdminDashboard() {
  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary to-secondary text-primary-foreground p-8 rounded-lg">
        <h1 className="text-4xl font-bold mb-2">VIPEX Parcel Dashboard</h1>
        <p className="text-primary-foreground/80">Manage escrow releases and parcel tracking</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Pending Parcels</p>
                <p className="text-3xl font-bold">34</p>
              </div>
              <Package className="w-10 h-10 text-yellow-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Delivered Today</p>
                <p className="text-3xl font-bold">12</p>
              </div>
              <CheckCircle className="w-10 h-10 text-green-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Escrow Held</p>
                <p className="text-3xl font-bold text-accent">₵45,230</p>
              </div>
              <DollarSign className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Released</p>
                <p className="text-3xl font-bold">₵128,450</p>
              </div>
              <ShoppingCart className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Escrow Releases */}
      <Card>
        <CardHeader>
          <CardTitle>Pending Escrow Releases</CardTitle>
          <CardDescription>Orders awaiting confirmation and fund release</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {[
            { order: 5001, buyer: "John Doe", seller: "TechHub", amount: 299.99, commission: 30.0 },
            { order: 5002, buyer: "Jane Smith", seller: "FashionFirst", amount: 149.99, commission: 15.0 },
            { order: 5003, buyer: "Bob Wilson", seller: "HomeStore", amount: 45.5, commission: 4.55 },
          ].map((item) => (
            <div key={item.order} className="border border-border rounded-lg p-4">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <p className="font-bold text-sm">Order #{item.order}</p>
                  <p className="text-xs text-muted-foreground">
                    {item.buyer} → {item.seller}
                  </p>
                </div>
                <p className="font-bold text-accent">₵{item.amount}</p>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-4 py-4 border-y border-border/50 text-sm">
                <div>
                  <p className="text-muted-foreground">Order Amount</p>
                  <p className="font-bold">₵{item.amount}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Commission (10%)</p>
                  <p className="font-bold">₵{item.commission}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Seller Payout</p>
                  <p className="font-bold text-accent">₵{(item.amount - item.commission).toFixed(2)}</p>
                </div>
              </div>

              <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
                Confirm Receipt & Release Funds
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Recent Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Actions</CardTitle>
          <CardDescription>Latest escrow releases and parcel confirmations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { action: "Funds Released", order: 4998, amount: "₵269.99", time: "2 hours ago" },
              { action: "Parcel Confirmed", order: 4997, amount: "₵189.50", time: "5 hours ago" },
              { action: "Funds Released", order: 4996, amount: "₵450.00", time: "1 day ago" },
            ].map((item, idx) => (
              <div key={idx} className="flex items-center justify-between pb-3 border-b border-border last:border-0">
                <div>
                  <p className="font-medium text-sm">{item.action}</p>
                  <p className="text-xs text-muted-foreground">
                    Order #{item.order} • {item.time}
                  </p>
                </div>
                <p className="font-bold text-accent">{item.amount}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
