"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, DollarSign } from "lucide-react"

export default function EscrowManagementPage() {
  const escrowTransactions = [
    {
      id: "ESC001",
      order: 5001,
      buyer: "John Doe",
      seller: "TechHub",
      amount: 299.99,
      held: "2025-12-02",
      status: "pending",
    },
    {
      id: "ESC002",
      order: 5002,
      buyer: "Jane Smith",
      seller: "FashionFirst",
      amount: 149.99,
      held: "2025-12-01",
      status: "confirmed",
    },
    {
      id: "ESC003",
      order: 5003,
      buyer: "Bob Wilson",
      seller: "HomeStore",
      amount: 45.5,
      held: "2025-11-30",
      status: "released",
    },
  ]

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Escrow Fund Management</h1>
        <div className="relative w-64">
          <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
          <Input placeholder="Search escrow..." className="pl-10" />
        </div>
      </div>

      {/* Escrow Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total in Escrow</p>
                <p className="text-3xl font-bold text-accent">₵45,230</p>
              </div>
              <DollarSign className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div>
              <p className="text-muted-foreground text-sm">Pending Confirmation</p>
              <p className="text-3xl font-bold">8 orders</p>
              <p className="text-xs text-yellow-600 mt-2">Worth ₵12,450.50</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div>
              <p className="text-muted-foreground text-sm">Today Released</p>
              <p className="text-3xl font-bold text-green-600">5 releases</p>
              <p className="text-xs text-green-600 mt-2">₵8,950.00 to sellers</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Escrow Transactions */}
      <Card>
        <CardHeader>
          <CardTitle>Escrow Transactions</CardTitle>
          <CardDescription>All escrow fund activities and releases</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold">Escrow ID</th>
                  <th className="text-left py-3 px-4 font-semibold">Order</th>
                  <th className="text-left py-3 px-4 font-semibold">Buyer → Seller</th>
                  <th className="text-left py-3 px-4 font-semibold">Amount</th>
                  <th className="text-left py-3 px-4 font-semibold">Held Since</th>
                  <th className="text-left py-3 px-4 font-semibold">Status</th>
                  <th className="text-left py-3 px-4 font-semibold">Action</th>
                </tr>
              </thead>
              <tbody>
                {escrowTransactions.map((tx) => (
                  <tr key={tx.id} className="border-b border-border hover:bg-muted/50">
                    <td className="py-3 px-4 font-mono text-xs">{tx.id}</td>
                    <td className="py-3 px-4 font-bold">#{tx.order}</td>
                    <td className="py-3 px-4">
                      {tx.buyer} → {tx.seller}
                    </td>
                    <td className="py-3 px-4 font-bold text-accent">₵{tx.amount}</td>
                    <td className="py-3 px-4 text-xs">{tx.held}</td>
                    <td className="py-3 px-4">
                      <Badge
                        className={`${tx.status === "pending" ? "bg-yellow-100 text-yellow-800" : tx.status === "confirmed" ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800"}`}
                      >
                        {tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      {tx.status === "pending" && (
                        <Button size="sm" className="bg-accent hover:bg-accent/90 text-accent-foreground text-xs">
                          Release
                        </Button>
                      )}
                      {tx.status === "confirmed" && <span className="text-xs text-green-600">Confirmed</span>}
                      {tx.status === "released" && <span className="text-xs text-muted-foreground">Completed</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
