"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Package, MapPin } from "lucide-react"

export default function ParcelsPage() {
  const parcels = [
    { id: "PKG001", tracking: "VIPEX-2025-12-001", buyer: "John Doe", status: "in_transit", destination: "Accra" },
    { id: "PKG002", tracking: "VIPEX-2025-12-002", buyer: "Jane Smith", status: "delivered", destination: "Kumasi" },
    { id: "PKG003", tracking: "VIPEX-2025-11-003", buyer: "Bob Wilson", status: "confirmed", destination: "Tema" },
  ]

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Parcel Tracking</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div>
              <p className="text-muted-foreground text-sm">In Transit</p>
              <p className="text-3xl font-bold">8</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div>
              <p className="text-muted-foreground text-sm">Delivered Today</p>
              <p className="text-3xl font-bold">12</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div>
              <p className="text-muted-foreground text-sm">Awaiting Confirmation</p>
              <p className="text-3xl font-bold">5</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Active Parcels</CardTitle>
          <CardDescription>Track parcel locations and status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {parcels.map((parcel) => (
              <div key={parcel.id} className="border border-border rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3">
                    <Package className="w-5 h-5 text-accent mt-1" />
                    <div>
                      <p className="font-bold">{parcel.tracking}</p>
                      <p className="text-sm text-muted-foreground">{parcel.buyer}</p>
                    </div>
                  </div>
                  <Badge
                    className={
                      parcel.status === "delivered"
                        ? "bg-green-100 text-green-800"
                        : parcel.status === "confirmed"
                          ? "bg-green-100 text-green-800"
                          : "bg-blue-100 text-blue-800"
                    }
                  >
                    {parcel.status.replace(/_/g, " ")}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  Destination: {parcel.destination}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
