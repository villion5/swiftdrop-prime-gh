"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

export default function TransactionsPage() {
  const transactions = [
    {
      id: "TXN001",
      order: 5001,
      buyer: "John Doe",
      seller: "TechHub",
      amount: 299.99,
      date: "2025-12-02",
      status: "escrow",
    },
    {
      id: "TXN002",
      order: 5002,
      buyer: "Jane Smith",
      seller: "FashionFirst",
      amount: 149.99,
      date: "2025-12-01",
      status: "completed",
    },
    {
      id: "TXN003",
      order: 5003,
      buyer: "Bob Wilson",
      seller: "HomeStore",
      amount: 45.5,
      date: "2025-11-30",
      status: "completed",
    },
  ]

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Transaction Management</h1>
        <div className="relative w-64">
          <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
          <Input placeholder="Search transactions..." className="pl-10" />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Transactions</CardTitle>
          <CardDescription>View all platform transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold">Transaction ID</th>
                  <th className="text-left py-3 px-4 font-semibold">Order</th>
                  <th className="text-left py-3 px-4 font-semibold">Buyer</th>
                  <th className="text-left py-3 px-4 font-semibold">Seller</th>
                  <th className="text-left py-3 px-4 font-semibold">Amount</th>
                  <th className="text-left py-3 px-4 font-semibold">Date</th>
                  <th className="text-left py-3 px-4 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx) => (
                  <tr key={tx.id} className="border-b border-border hover:bg-muted/50">
                    <td className="py-3 px-4 font-mono">#{tx.id}</td>
                    <td className="py-3 px-4">#{tx.order}</td>
                    <td className="py-3 px-4">{tx.buyer}</td>
                    <td className="py-3 px-4">{tx.seller}</td>
                    <td className="py-3 px-4 font-bold text-accent">₵{tx.amount}</td>
                    <td className="py-3 px-4">{tx.date}</td>
                    <td className="py-3 px-4">
                      <Badge
                        className={
                          tx.status === "completed" ? "bg-green-100 text-green-800" : "bg-blue-100 text-blue-800"
                        }
                      >
                        {tx.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
