import { createClient } from "@supabase/supabase-js"
import { type NextRequest, NextResponse } from "next/server"
import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

    const body = await request.json()
    const { email, password } = body

    console.log("[v0] Login attempt:", email)

    const { data: users, error: userError } = await supabase.from("users").select("*").eq("email", email)

    if (userError || !users || users.length === 0) {
      console.log("[v0] User not found:", email)
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    const user = users[0]

    // Check password
    const passwordMatch = await bcrypt.compare(password, user.password_hash)

    if (!passwordMatch) {
      console.log("[v0] Password mismatch for:", email)
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    // Create JWT token
    const token = jwt.sign({ userId: user.id, userType: user.user_type }, process.env.SUPABASE_JWT_SECRET!, {
      expiresIn: "7d",
    })

    // Set cookie
    const response = NextResponse.json(
      {
        message: "Login successful",
        redirectTo: user.user_type === "buyer" ? "/" : "/seller/profile",
      },
      { status: 200 },
    )

    response.cookies.set("auth_token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 7 * 24 * 60 * 60,
    })

    console.log("[v0] Login successful for:", email)

    return response
  } catch (error) {
    console.log("[v0] Login error:", error)
    return NextResponse.json({ error: error instanceof Error ? error.message : "Internal error" }, { status: 500 })
  }
}
