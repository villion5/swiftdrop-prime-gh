import { createClient } from "@supabase/supabase-js"
import { type NextRequest, NextResponse } from "next/server"
import bcrypt from "bcryptjs"

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

    const body = await request.json()
    const { email, password, firstName, lastName, phone, userType, businessName, businessCategory, momoAccount } = body

    console.log("[v0] Signup attempt:", { email, userType })

    // Check if user already exists
    const { data: existingUsers } = await supabase.from("users").select("id").eq("email", email)

    if (existingUsers && existingUsers.length > 0) {
      return NextResponse.json({ error: "User already exists" }, { status: 400 })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    const { data: newUser, error: userError } = await supabase
      .from("users")
      .insert({
        email,
        password_hash: hashedPassword,
        user_type: userType,
        first_name: firstName,
        last_name: lastName,
        phone_number: phone,
      })
      .select()

    if (userError || !newUser || newUser.length === 0) {
      console.log("[v0] User creation error:", userError)
      return NextResponse.json({ error: userError?.message || "Failed to create user" }, { status: 400 })
    }

    const createdUser = newUser[0]

    // Create buyer or seller profile
    if (userType === "buyer") {
      await supabase.from("buyer_profiles").insert({
        user_id: createdUser.id,
      })
    } else if (userType === "seller") {
      await supabase.from("seller_profiles").insert({
        user_id: createdUser.id,
        business_name: businessName || null,
        business_category: businessCategory || null,
        momo_account: momoAccount || null,
      })
    }

    console.log("[v0] User created successfully:", createdUser.id)

    return NextResponse.json(
      {
        message: "Signup successful",
        userType: userType,
      },
      { status: 201 },
    )
  } catch (error) {
    console.log("[v0] Signup error:", error)
    return NextResponse.json({ error: error instanceof Error ? error.message : "Internal error" }, { status: 500 })
  }
}
