import { createClient } from "@supabase/supabase-js"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

    const body = await request.json()
    const { orderId, reason } = body

    // Get order details
    const { data: orders } = await supabase.from("orders").select("*").eq("id", orderId)

    if (!orders || orders.length === 0 || orders[0].status !== "pending") {
      return NextResponse.json({ error: "Can only cancel pending orders" }, { status: 400 })
    }

    const order = orders[0]

    // Update order status
    const { error: updateError } = await supabase
      .from("orders")
      .update({
        status: "cancelled",
        updated_at: new Date().toISOString(),
      })
      .eq("id", orderId)

    if (updateError) {
      return NextResponse.json({ error: updateError.message }, { status: 400 })
    }

    // Get escrow record
    const { data: escrows } = await supabase.from("escrow").select("*").eq("order_id", orderId)

    if (escrows && escrows.length > 0) {
      const escrow = escrows[0]
      if (escrow.status === "held") {
        // Update escrow status
        await supabase.from("escrow").update({ status: "refunded" }).eq("id", escrow.id)

        // Record refund transaction
        await supabase.from("wallet_transactions").insert({
          user_id: order.buyer_id,
          transaction_type: "refund",
          amount: escrow.amount,
          status: "pending",
        })
      }
    }

    return NextResponse.json({ message: "Order cancelled and funds refunded" }, { status: 200 })
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Internal error" }, { status: 500 })
  }
}
