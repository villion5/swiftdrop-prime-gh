import { createClient } from "@supabase/supabase-js"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

    const body = await request.json()
    const { escrowId } = body

    // Get escrow record
    const { data: escrows, error: escrowError } = await supabase.from("escrow").select("*").eq("id", escrowId)

    if (escrowError || !escrows || escrows.length === 0) {
      return NextResponse.json({ error: "Escrow record not found" }, { status: 404 })
    }

    const escrow = escrows[0]

    if (escrow.status !== "held") {
      return NextResponse.json({ error: "Escrow already released or refunded" }, { status: 400 })
    }

    // Calculate payout with 10% commission
    const commissionAmount = escrow.amount * 0.1
    const sellerPayout = escrow.amount - commissionAmount

    // Update escrow status to released
    const { error: updateError } = await supabase
      .from("escrow")
      .update({
        status: "released",
        released_at: new Date().toISOString(),
      })
      .eq("id", escrowId)

    if (updateError) {
      return NextResponse.json({ error: updateError.message }, { status: 400 })
    }

    // Record payout transaction for seller
    await supabase.from("wallet_transactions").insert({
      user_id: escrow.seller_id,
      transaction_type: "payout",
      amount: sellerPayout,
      status: "pending",
    })

    // Update order status to delivered
    await supabase.from("orders").update({ status: "delivered" }).eq("id", escrow.order_id)

    return NextResponse.json(
      {
        message: "Escrow released successfully",
        sellerPayout,
        commissionDeducted: commissionAmount,
      },
      { status: 200 },
    )
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Internal error" }, { status: 500 })
  }
}
