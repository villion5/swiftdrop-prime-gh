import { createClient } from "@supabase/supabase-js"
import { type NextRequest, NextResponse } from "next/server"
import Stripe from "stripe"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

    const body = await request.json()
    const { userId, amount, paymentMethodId } = body

    // Create Stripe payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // Convert to cents
      currency: "ghs",
      payment_method: paymentMethodId,
      confirm: true,
      metadata: {
        userId,
        type: "wallet_deposit",
      },
    })

    if (paymentIntent.status === "succeeded") {
      // Create wallet transaction
      const { data: transaction, error: txError } = await supabase
        .from("wallet_transactions")
        .insert({
          user_id: userId,
          transaction_type: "deposit",
          amount,
          status: "completed",
        })
        .select()

      if (txError) {
        return NextResponse.json({ error: txError.message }, { status: 400 })
      }

      return NextResponse.json({ message: "Deposit successful", transaction }, { status: 200 })
    } else {
      return NextResponse.json({ error: "Payment failed" }, { status: 400 })
    }
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Internal error" }, { status: 500 })
  }
}
