import { createClient } from "@supabase/supabase-js"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

    const body = await request.json()
    const { buyerId, sellerId, productId, quantity, totalPrice } = body

    // Create order
    const { data: orders, error: orderError } = await supabase
      .from("orders")
      .insert({
        buyer_id: buyerId,
        seller_id: sellerId,
        product_id: productId,
        quantity,
        total_price: totalPrice,
        status: "paid",
      })
      .select()

    if (orderError || !orders || orders.length === 0) {
      return NextResponse.json({ error: orderError?.message || "Failed to create order" }, { status: 400 })
    }

    const order = orders[0]

    // Create escrow fund record
    const commission = totalPrice * 0.1 // 10% commission
    const { data: escrows, error: escrowError } = await supabase
      .from("escrow")
      .insert({
        order_id: order.id,
        amount: totalPrice,
        status: "held",
        commission_rate: 0.1,
      })
      .select()

    if (escrowError) {
      return NextResponse.json({ error: escrowError.message }, { status: 400 })
    }

    // Record transaction
    await supabase.from("wallet_transactions").insert({
      user_id: buyerId,
      transaction_type: "purchase",
      amount: -totalPrice,
      status: "completed",
    })

    return NextResponse.json(
      {
        message: "Purchase successful",
        order,
      },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Internal error" }, { status: 500 })
  }
}
