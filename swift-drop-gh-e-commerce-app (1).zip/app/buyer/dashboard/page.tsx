"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Heart, TrendingUp, AlertCircle } from "lucide-react"
import Link from "next/link"

export default function BuyerDashboard() {
  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary to-secondary text-primary-foreground p-8 rounded-lg">
        <h1 className="text-4xl font-bold mb-2">Welcome back, John!</h1>
        <p className="text-primary-foreground/80">Ready to find something amazing today?</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Active Orders</p>
                <p className="text-3xl font-bold">2</p>
              </div>
              <ShoppingCart className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Saved Items</p>
                <p className="text-3xl font-bold">5</p>
              </div>
              <Heart className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Wallet Balance</p>
                <p className="text-3xl font-bold text-accent">₵0.00</p>
              </div>
              <TrendingUp className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Spent</p>
                <p className="text-3xl font-bold">₵0.00</p>
              </div>
              <TrendingUp className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle>Recommended for You</CardTitle>
          <CardDescription>Based on your browsing history</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <AlertCircle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No recommendations yet. Start exploring products!</p>
            <Link href="/buyer/search">
              <Button className="mt-4 bg-accent hover:bg-accent/90 text-accent-foreground">Browse Products</Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
