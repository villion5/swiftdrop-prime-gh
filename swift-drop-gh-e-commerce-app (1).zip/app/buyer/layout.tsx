"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Search, Home, Heart, User, LogOut, Menu, X } from "lucide-react"

export default function BuyerLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const menuItems = [
    { href: "/buyer/dashboard", label: "Dashboard", icon: Home },
    { href: "/buyer/search", label: "Browse", icon: Search },
    { href: "/buyer/orders", label: "Orders", icon: ShoppingCart },
    { href: "/buyer/wishlist", label: "Wishlist", icon: Heart },
    { href: "/buyer/wallet", label: "Wallet", icon: ShoppingCart },
    { href: "/buyer/profile", label: "Profile", icon: User },
  ]

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <aside
        className={`${sidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-50 w-64 bg-primary text-primary-foreground transition-transform duration-300`}
      >
        <div className="p-6 border-b border-primary-foreground/20">
          <Link href="/" className="flex items-center gap-2">
            <ShoppingCart className="w-8 h-8" />
            <span className="text-xl font-bold">SwiftDropGH</span>
          </Link>
        </div>

        <nav className="p-4 space-y-2">
          {menuItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <Button
                variant="ghost"
                className="w-full justify-start text-primary-foreground hover:bg-primary-foreground/10"
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.label}
              </Button>
            </Link>
          ))}
        </nav>

        <div className="absolute bottom-4 left-4 right-4">
          <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="bg-white border-b border-border h-16 flex items-center px-6 shadow-sm">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden -ml-2 p-2 hover:bg-muted rounded-lg"
          >
            {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          <div className="flex-1" />

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="font-semibold text-sm">Balance</div>
              <div className="text-accent font-bold">₵0.00</div>
            </div>
            <Link href="/buyer/wallet">
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground text-sm">+ Add Money</Button>
            </Link>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto bg-muted/30">{children}</main>
      </div>
    </div>
  )
}
