"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Truck, MapPin, AlertCircle, Clock } from "lucide-react"
import { useParams } from "next/navigation"

export default function OrderDetailPage() {
  const params = useParams()
  const orderId = params.id

  const order = {
    id: 5002,
    product: "Winter Jacket",
    seller: "FashionFirst",
    sellerRating: 4.8,
    amount: 149.99,
    quantity: 1,
    date: "2025-12-01",
    status: "shipped",
    trackingNumber: "VIPEX-2025-12-002",
    deliveryAddress: "VIPEX Parcel Office, Kumasi Central Market",
    estimatedDelivery: "2025-12-05",
  }

  const handleConfirmDelivery = async () => {
    try {
      const response = await fetch("/api/orders/release-escrow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId,
        }),
      })

      if (response.ok) {
        // Show success and refresh
      }
    } catch (error) {
      console.error("Confirm delivery failed:", error)
    }
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Order #{order.id}</h1>
        <Badge className="bg-blue-100 text-blue-800 flex items-center gap-1">
          <Truck className="w-4 h-4" />
          Shipped
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Order Timeline */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Delivery Timeline</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <CheckCircle className="w-6 h-6 text-green-600 mb-2" />
                    <div className="w-1 h-12 bg-green-600" />
                  </div>
                  <div>
                    <p className="font-bold">Order Placed</p>
                    <p className="text-sm text-muted-foreground">{order.date}</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <Truck className="w-6 h-6 text-blue-600 mb-2" />
                    <div className="w-1 h-12 bg-gray-300" />
                  </div>
                  <div>
                    <p className="font-bold">In Transit</p>
                    <p className="text-sm text-muted-foreground">Expected by {order.estimatedDelivery}</p>
                    <p className="text-xs text-accent font-mono mt-2">Tracking: {order.trackingNumber}</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <Clock className="w-6 h-6 text-gray-400" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-500">Confirm Receipt</p>
                    <p className="text-sm text-muted-foreground">Collect at VIPEX and confirm delivery</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Product Info */}
          <Card>
            <CardHeader>
              <CardTitle>Product Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-bold text-lg">{order.product}</p>
                  <p className="text-sm text-muted-foreground">by {order.seller}</p>
                  <p className="text-xs text-muted-foreground mt-1">Quantity: {order.quantity}</p>
                </div>
                <p className="text-3xl font-bold text-accent">₵{order.amount}</p>
              </div>
            </CardContent>
          </Card>

          {/* Escrow Protection Info */}
          <Card className="border-accent/20 bg-accent/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5" />
                Escrow Protection
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Your payment of ₵{order.amount} is securely held in escrow until you confirm delivery at the VIPEX
                parcel office.
              </p>
              <div className="bg-accent/10 p-3 rounded-lg space-y-2 text-xs">
                <p className="font-medium">When you arrive at the VIPEX office:</p>
                <ol className="list-decimal list-inside space-y-1">
                  <li>Show your tracking number: {order.trackingNumber}</li>
                  <li>Inspect the package contents</li>
                  <li>Confirm receipt in the system</li>
                  <li>Seller receives payment immediately</li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Summary Card */}
        <Card className="h-fit">
          <CardHeader>
            <CardTitle>Delivery Address</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-start gap-2">
              <MapPin className="w-5 h-5 text-accent mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-medium">{order.deliveryAddress}</p>
              </div>
            </div>

            <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">Get Directions</Button>

            <div className="space-y-3 border-t border-border pt-4">
              <p className="text-sm font-medium">Need Help?</p>
              <Button variant="outline" className="w-full border-border hover:bg-muted bg-transparent">
                Contact VIPEX
              </Button>
              <Button variant="outline" className="w-full border-border hover:bg-muted bg-transparent">
                Contact Seller
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
