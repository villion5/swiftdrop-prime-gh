"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Truck, MapPin, Clock, AlertCircle } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function BuyerOrdersPage() {
  const [selectedOrder, setSelectedOrder] = useState<string | null>(null)
  const [cancelReason, setCancelReason] = useState("")
  const [showCancelDialog, setShowCancelDialog] = useState(false)

  const orders = [
    {
      id: 5001,
      product: "Premium Wireless Headphones",
      seller: "TechHub",
      amount: 299.99,
      quantity: 1,
      date: "2025-12-02",
      status: "processing",
      trackingNumber: "VIPEX-2025-12-001",
      deliveryAddress: "P.O Box 123, Accra",
    },
    {
      id: 5002,
      product: "Winter Jacket",
      seller: "FashionFirst",
      amount: 149.99,
      quantity: 1,
      date: "2025-12-01",
      status: "shipped",
      trackingNumber: "VIPEX-2025-12-002",
      deliveryAddress: "Kumasi Central Market",
    },
    {
      id: 5003,
      product: "LED Lamp",
      seller: "HomeStore",
      amount: 45.5,
      quantity: 2,
      date: "2025-11-30",
      status: "delivered",
      trackingNumber: "VIPEX-2025-11-003",
      deliveryAddress: "VIPEX Parcel Office, Tema",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "processing":
        return "bg-yellow-100 text-yellow-800"
      case "shipped":
        return "bg-blue-100 text-blue-800"
      case "delivered":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "processing":
        return <Clock className="w-4 h-4" />
      case "shipped":
        return <Truck className="w-4 h-4" />
      case "delivered":
        return <ShoppingCart className="w-4 h-4" />
      default:
        return null
    }
  }

  const handleCancelOrder = async (orderId: string) => {
    try {
      const response = await fetch("/api/orders/cancel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId,
          reason: cancelReason,
        }),
      })

      if (response.ok) {
        // Refresh orders or show success message
        setShowCancelDialog(false)
        setCancelReason("")
      }
    } catch (error) {
      console.error("Cancel failed:", error)
    }
  }

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">My Orders</h1>

      <div className="space-y-4">
        {orders.map((order) => (
          <Card key={order.id} className="border-border/50">
            <CardContent className="p-6">
              <div className="space-y-4">
                {/* Order Header */}
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-bold text-lg">Order #{order.id}</p>
                    <p className="text-sm text-muted-foreground">{order.date}</p>
                  </div>
                  <Badge className={`flex items-center gap-1 ${getStatusColor(order.status)}`}>
                    {getStatusIcon(order.status)}
                    {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                  </Badge>
                </div>

                {/* Product Info */}
                <div className="bg-muted/30 p-4 rounded-lg">
                  <div className="flex justify-between mb-2">
                    <div>
                      <p className="font-medium">{order.product}</p>
                      <p className="text-sm text-muted-foreground">by {order.seller}</p>
                      <p className="text-xs text-muted-foreground mt-1">Quantity: {order.quantity}</p>
                    </div>
                    <p className="text-2xl font-bold text-accent">₵{order.amount}</p>
                  </div>
                </div>

                {/* Delivery Info */}
                <div className="space-y-2">
                  <div className="flex items-start gap-2">
                    <Truck className="w-4 h-4 text-muted-foreground mt-1" />
                    <div>
                      <p className="font-medium text-sm">Tracking Number</p>
                      <p className="text-sm text-muted-foreground">{order.trackingNumber}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground mt-1" />
                    <div>
                      <p className="font-medium text-sm">Delivery Address</p>
                      <p className="text-sm text-muted-foreground">{order.deliveryAddress}</p>
                    </div>
                  </div>
                </div>

                {/* Escrow Info */}
                {order.status !== "delivered" && (
                  <div className="bg-accent/10 border border-accent/20 p-3 rounded-lg flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                    <div className="text-sm">
                      <p className="font-medium text-accent">Secure Escrow Protection Active</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        Your payment is held safely until you confirm receipt at the VIPEX parcel office.
                      </p>
                    </div>
                  </div>
                )}

                {order.status === "delivered" && (
                  <div className="bg-green-50 border border-green-200 p-3 rounded-lg flex items-start gap-2">
                    <ShoppingCart className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <div className="text-sm">
                      <p className="font-medium text-green-800">Delivery Confirmed</p>
                      <p className="text-xs text-green-700 mt-1">
                        Seller has received payment. You can now write a review.
                      </p>
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2 justify-end">
                  {order.status === "processing" && (
                    <>
                      <Button variant="outline" className="border-border hover:bg-muted bg-transparent">
                        Contact Seller
                      </Button>
                      <Button
                        variant="outline"
                        className="border-destructive text-destructive hover:bg-destructive/5 bg-transparent"
                        onClick={() => {
                          setSelectedOrder(order.id.toString())
                          setShowCancelDialog(true)
                        }}
                      >
                        Cancel Order
                      </Button>
                    </>
                  )}
                  {order.status === "shipped" && (
                    <Button variant="outline" className="border-border hover:bg-muted bg-transparent">
                      Track Package
                    </Button>
                  )}
                  {order.status === "delivered" && (
                    <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">Write Review</Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Cancel Order Dialog */}
      <AlertDialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Order</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to cancel this order? Your payment will be refunded immediately to your wallet.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-3 my-4">
            <textarea
              placeholder="Tell us why you're cancelling (optional)"
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              className="w-full px-3 py-2 border border-border rounded-md bg-background resize-none"
              rows={3}
            />
          </div>
          <div className="flex gap-2 justify-end">
            <AlertDialogCancel>Keep Order</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (selectedOrder) {
                  handleCancelOrder(selectedOrder)
                }
              }}
              className="bg-destructive hover:bg-destructive/90"
            >
              Cancel Order
            </AlertDialogAction>
          </div>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
