"use client"

import { useState, Suspense } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ShoppingCart, Star, Sliders } from "lucide-react"

function SearchContent() {
  const [filters, setFilters] = useState({
    searchQuery: "",
    category: "",
    minPrice: 0,
    maxPrice: 10000,
    minRating: 0,
  })

  // Mock products
  const products = [
    { id: 1, name: "Wireless Headphones", price: 299.99, rating: 4.8, seller: "TechHub", category: "Electronics" },
    { id: 2, name: "Winter Jacket", price: 149.99, rating: 4.6, seller: "FashionFirst", category: "Fashion" },
    { id: 3, name: "Coffee Beans", price: 24.99, rating: 4.9, seller: "BrownBeans", category: "Grocery" },
    { id: 4, name: "Fitness Watch", price: 199.99, rating: 4.7, seller: "FitGear", category: "Electronics" },
  ]

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Search Products</h1>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Filters Sidebar */}
        <Card className="h-fit">
          <CardContent className="p-6 space-y-6">
            <div>
              <Label className="font-bold flex items-center gap-2 mb-2">
                <Sliders className="w-4 h-4" />
                Filters
              </Label>
            </div>

            <div className="space-y-2">
              <Label htmlFor="search" className="text-sm">
                Search
              </Label>
              <Input
                id="search"
                placeholder="Product name..."
                value={filters.searchQuery}
                onChange={(e) => setFilters({ ...filters, searchQuery: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category" className="text-sm">
                Category
              </Label>
              <select
                id="category"
                value={filters.category}
                onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                className="w-full px-3 py-2 border border-border rounded-md bg-background"
              >
                <option value="">All Categories</option>
                <option value="Electronics">Electronics</option>
                <option value="Fashion">Fashion</option>
                <option value="Grocery">Grocery</option>
              </select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="minPrice" className="text-sm">
                Min Price: ₵{filters.minPrice}
              </Label>
              <input
                id="minPrice"
                type="range"
                min="0"
                max="10000"
                step="100"
                value={filters.minPrice}
                onChange={(e) => setFilters({ ...filters, minPrice: Number(e.target.value) })}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxPrice" className="text-sm">
                Max Price: ₵{filters.maxPrice}
              </Label>
              <input
                id="maxPrice"
                type="range"
                min="0"
                max="10000"
                step="100"
                value={filters.maxPrice}
                onChange={(e) => setFilters({ ...filters, maxPrice: Number(e.target.value) })}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="rating" className="text-sm">
                Min Rating: {filters.minRating}★
              </Label>
              <input
                id="rating"
                type="range"
                min="0"
                max="5"
                step="0.5"
                value={filters.minRating}
                onChange={(e) => setFilters({ ...filters, minRating: Number(e.target.value) })}
                className="w-full"
              />
            </div>

            <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">Apply Filters</Button>
          </CardContent>
        </Card>

        {/* Products Grid */}
        <div className="lg:col-span-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <Card key={product.id} className="hover:shadow-lg transition-shadow border-border/50">
                <div className="bg-muted h-48 flex items-center justify-center mb-4">
                  <ShoppingCart className="w-12 h-12 text-muted-foreground" />
                </div>
                <CardContent className="space-y-3">
                  <h3 className="font-bold text-sm line-clamp-2">{product.name}</h3>
                  <div className="flex justify-between items-center">
                    <span className="text-accent font-bold text-lg">₵{product.price}</span>
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Star className="w-3 h-3 fill-accent text-accent" />
                      {product.rating}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">by {product.seller}</p>
                  <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground text-sm">
                    View Details
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="p-6">Loading...</div>}>
      <SearchContent />
    </Suspense>
  )
}
