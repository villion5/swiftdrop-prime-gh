"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { CreditCard, ArrowUpRight, ArrowDownLeft } from "lucide-react"

export default function WalletPage() {
  const [depositAmount, setDepositAmount] = useState("")

  const transactions = [
    { id: 1, type: "deposit", amount: 500, date: "2025-12-01", status: "completed", description: "Wallet Top-up" },
    {
      id: 2,
      type: "purchase",
      amount: -199.99,
      date: "2025-11-28",
      status: "completed",
      description: "Purchase - Fitness Watch",
    },
    { id: 3, type: "refund", amount: 199.99, date: "2025-11-25", status: "completed", description: "Order Refund" },
  ]

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">SwiftDrop Wallet</h1>

      {/* Balance Card */}
      <Card className="bg-gradient-to-r from-primary to-secondary text-primary-foreground border-0">
        <CardContent className="p-8">
          <p className="text-primary-foreground/80 mb-2">Available Balance</p>
          <p className="text-5xl font-bold mb-4">₵0.00</p>
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">View Details</Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Deposit Section */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Add Money
            </CardTitle>
            <CardDescription>Top up your wallet balance</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount (₵)</Label>
              <Input
                id="amount"
                type="number"
                placeholder="Enter amount"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                min="1"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm">Quick Amount</Label>
              <div className="grid grid-cols-3 gap-2">
                {[50, 100, 500].map((amount) => (
                  <Button
                    key={amount}
                    variant="outline"
                    onClick={() => setDepositAmount(amount.toString())}
                    className="border-border hover:border-accent"
                  >
                    ₵{amount}
                  </Button>
                ))}
              </div>
            </div>

            <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">Deposit Now</Button>
          </CardContent>
        </Card>

        {/* Transaction History */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>Your recent wallet activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {transactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between border-b border-border pb-4 last:border-0"
                >
                  <div className="flex items-center gap-4">
                    <div
                      className={`p-2 rounded-full ${transaction.type === "deposit" || transaction.type === "refund" ? "bg-green-500/10" : "bg-red-500/10"}`}
                    >
                      {transaction.type === "deposit" || transaction.type === "refund" ? (
                        <ArrowDownLeft className="w-5 h-5 text-green-600" />
                      ) : (
                        <ArrowUpRight className="w-5 h-5 text-red-600" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium">{transaction.description}</p>
                      <p className="text-xs text-muted-foreground">{transaction.date}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${transaction.amount > 0 ? "text-green-600" : "text-red-600"}`}>
                      {transaction.amount > 0 ? "+" : ""}
                      {transaction.amount}
                    </p>
                    <span className="text-xs text-muted-foreground capitalize">{transaction.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
