"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ShoppingCart, AlertCircle } from "lucide-react"

export default function WishlistPage() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">My Wishlist</h1>
        <p className="text-muted-foreground">Items saved for later</p>
      </div>

      <Card>
        <CardContent className="p-12">
          <div className="text-center">
            <AlertCircle className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-4">Your wishlist is empty</p>
            <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
              <ShoppingCart className="w-4 h-4 mr-2" />
              Browse Products
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
