"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { ShoppingCart, Search, Lock, Users, Zap, Wallet } from "lucide-react"

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState("")

  const features = [
    {
      icon: Lock,
      title: "Secure Escrow",
      description: "Your funds are protected until you confirm receipt of your order",
    },
    {
      icon: Users,
      title: "Verified Sellers",
      description: "Buy from trusted sellers with verified ratings and reviews",
    },
    {
      icon: Zap,
      title: "Fast Delivery",
      description: "Quick and reliable delivery through VIPEX Parcel Service",
    },
    {
      icon: Wallet,
      title: "Easy Payments",
      description: "Pay securely with SwiftDrop Wallet or multiple payment methods",
    },
  ]

  const categories = [
    { name: "Electronics", color: "from-blue-600 to-blue-700" },
    { name: "Fashion", color: "from-purple-600 to-purple-700" },
    { name: "Books", color: "from-amber-600 to-amber-700" },
    { name: "Home & Garden", color: "from-green-600 to-green-700" },
    { name: "Sports", color: "from-red-600 to-red-700" },
    { name: "Beauty", color: "from-pink-600 to-pink-700" },
  ]

  const featuredProducts = [
    { id: 1, name: "Premium Wireless Headphones", price: 299.99, rating: 4.8, seller: "TechHub" },
    { id: 2, name: "Stylish Winter Jacket", price: 149.99, rating: 4.6, seller: "FashionFirst" },
    { id: 3, name: "Organic Coffee Beans", price: 24.99, rating: 4.9, seller: "BrownBeans" },
    { id: 4, name: "Fitness Tracker Watch", price: 199.99, rating: 4.7, seller: "FitGear" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-primary text-primary-foreground shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2">
            <ShoppingCart className="w-8 h-8" />
            <span className="text-2xl font-bold">SwiftDropGH</span>
          </Link>
          <div className="flex gap-4">
            <Link href="/auth/login">
              <Button
                variant="outline"
                className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary bg-transparent"
              >
                Login
              </Button>
            </Link>
            <Link href="/auth/signup">
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">Sign Up</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary via-secondary to-primary text-primary-foreground py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-5xl font-bold mb-4">Welcome to SwiftDropGH</h1>
            <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
              Your secure marketplace with escrow protection, verified sellers, and fast delivery
            </p>
          </div>

          {/* Search Bar */}
          <div className="flex gap-2 max-w-2xl mx-auto mb-6">
            <div className="flex-1 relative">
              <Input
                type="text"
                placeholder="Search products, sellers, or categories..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-12 bg-primary-foreground text-foreground border-0"
              />
              <Search className="absolute left-4 top-3 w-6 h-6 text-muted-foreground" />
            </div>
            <Link href={`/buyer/search?q=${searchQuery}`}>
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground h-12 px-8">Search</Button>
            </Link>
          </div>

          {/* Quick CTA */}
          <div className="text-center">
            <Link href="/auth/signup">
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground text-lg px-8 py-6">
                Start Shopping Now
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-12">Why Choose SwiftDropGH?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, idx) => (
              <Card key={idx} className="border-border/50 hover:border-accent transition-colors">
                <CardContent className="p-6 text-center">
                  <feature.icon className="w-12 h-12 mx-auto mb-4 text-accent" />
                  <h3 className="font-bold text-lg mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold mb-12">Shop by Category</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category, idx) => (
              <Link key={idx} href={`/buyer/search?category=${category.name}`}>
                <Card
                  className={`bg-gradient-to-br ${category.color} text-white cursor-pointer hover:shadow-lg transition-shadow h-32 flex items-center justify-center`}
                >
                  <CardContent className="text-center">
                    <h3 className="text-2xl font-bold">{category.name}</h3>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold mb-12">Featured Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <Card key={product.id} className="hover:shadow-lg transition-shadow border-border/50">
                <div className="bg-muted h-48 flex items-center justify-center mb-4">
                  <ShoppingCart className="w-12 h-12 text-muted-foreground" />
                </div>
                <CardContent className="space-y-3">
                  <h3 className="font-bold text-sm line-clamp-2">{product.name}</h3>
                  <div className="flex justify-between items-center">
                    <span className="text-accent font-bold text-lg">₵{product.price}</span>
                    <span className="text-xs text-muted-foreground">⭐ {product.rating}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">by {product.seller}</p>
                  <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground text-sm">
                    View Product
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-8">Trusted by Thousands</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            <div>
              <p className="text-4xl font-bold text-accent">50K+</p>
              <p className="text-primary-foreground/80">Active Buyers & Sellers</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-accent">100K+</p>
              <p className="text-primary-foreground/80">Products Listed</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-accent">99.8%</p>
              <p className="text-primary-foreground/80">Secure Transactions</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary text-secondary-foreground py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">About</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="hover:text-accent">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-accent">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-accent">
                    Careers
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Help</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="hover:text-accent">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-accent">
                    FAQ
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-accent">
                    Support
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="hover:text-accent">
                    Privacy
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-accent">
                    Terms
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-accent">
                    Security
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Follow Us</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="hover:text-accent">
                    Facebook
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-accent">
                    Twitter
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-accent">
                    Instagram
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-secondary-foreground/20 pt-8 text-center text-sm">
            <p>&copy; 2025 SwiftDropGH. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
