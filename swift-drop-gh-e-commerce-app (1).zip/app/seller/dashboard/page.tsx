"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Package, ShoppingCart, TrendingUp, DollarSign } from "lucide-react"
import Link from "next/link"

export default function SellerDashboard() {
  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary to-secondary text-primary-foreground p-8 rounded-lg">
        <h1 className="text-4xl font-bold mb-2">Welcome back, TechHub!</h1>
        <p className="text-primary-foreground/80">Manage your products, orders, and payments all in one place</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Active Products</p>
                <p className="text-3xl font-bold">24</p>
              </div>
              <Package className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Pending Orders</p>
                <p className="text-3xl font-bold">7</p>
              </div>
              <ShoppingCart className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Sales</p>
                <p className="text-3xl font-bold">₵15,420</p>
              </div>
              <TrendingUp className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Available Payout</p>
                <p className="text-3xl font-bold text-accent">₵2,850</p>
              </div>
              <DollarSign className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Orders */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
          <CardDescription>Your latest sales activity</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((order) => (
              <div key={order} className="flex items-center justify-between border-b border-border pb-4 last:border-0">
                <div>
                  <p className="font-medium">Order #{1000 + order}</p>
                  <p className="text-sm text-muted-foreground">Premium Wireless Headphones × 1</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-accent">₵299.99</p>
                  <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">Processing</span>
                </div>
              </div>
            ))}
          </div>
          <Link href="/seller/orders" className="mt-4 inline-block">
            <Button variant="outline" className="border-border hover:bg-muted bg-transparent">
              View All Orders
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  )
}
