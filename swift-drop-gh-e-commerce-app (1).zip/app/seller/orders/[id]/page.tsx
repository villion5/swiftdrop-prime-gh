"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Truck, MapPin } from "lucide-react"
import { useParams } from "next/navigation"

export default function OrderDetailPage() {
  const params = useParams()
  const orderId = params.id
  const [trackingNumber, setTrackingNumber] = useState("")
  const [loading, setLoading] = useState(false)

  const order = {
    id: 5001,
    buyer: "John Doe",
    buyerPhone: "+233 500 000 123",
    buyerEmail: "john@example.com",
    product: "Premium Wireless Headphones",
    quantity: 1,
    price: 299.99,
    date: "2025-12-02",
    status: "pending",
    shippingAddress: "P.O Box 123, Accra, Ghana",
  }

  const handleMarkShipped = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/orders/mark-shipped", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId,
          trackingNumber,
        }),
      })

      if (response.ok) {
        // Show success message and redirect
        setTrackingNumber("")
      }
    } catch (error) {
      console.error("Mark shipped failed:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Order #{order.id}</h1>
        <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Order Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Product Info */}
          <Card>
            <CardHeader>
              <CardTitle>Product Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-bold text-lg">{order.product}</p>
                  <p className="text-sm text-muted-foreground">Quantity: {order.quantity}</p>
                </div>
                <p className="text-3xl font-bold text-accent">₵{order.price}</p>
              </div>
              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-xs text-muted-foreground mb-2">Order Date</p>
                <p className="font-medium">{order.date}</p>
              </div>
            </CardContent>
          </Card>

          {/* Buyer Info */}
          <Card>
            <CardHeader>
              <CardTitle>Buyer Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Name</p>
                <p className="font-medium">{order.buyer}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="font-medium text-accent">{order.buyerEmail}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Phone</p>
                <p className="font-medium">{order.buyerPhone}</p>
              </div>
            </CardContent>
          </Card>

          {/* Shipping Address */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Shipping Address
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-medium">{order.shippingAddress}</p>
            </CardContent>
          </Card>

          {/* Mark as Shipped */}
          <Card className="border-accent/20 bg-accent/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="w-5 h-5" />
                Mark Order as Shipped
              </CardTitle>
              <CardDescription>Prepare package and provide VIPEX tracking number</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <p className="text-sm font-medium text-yellow-900">
                  ⚠ Remember to prepare the package and deliver it to your nearest VIPEX parcel office.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="tracking">VIPEX Tracking Number *</Label>
                <Input
                  id="tracking"
                  placeholder="e.g., VIPEX-2025-12-001"
                  value={trackingNumber}
                  onChange={(e) => setTrackingNumber(e.target.value)}
                  disabled={loading}
                />
              </div>

              <Button
                onClick={handleMarkShipped}
                disabled={loading || !trackingNumber}
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                {loading ? "Marking as Shipped..." : "Mark as Shipped"}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Payment Summary */}
        <Card className="h-fit bg-gradient-to-br from-primary to-secondary text-primary-foreground">
          <CardHeader>
            <CardTitle>Escrow Summary</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between">
              <span className="text-primary-foreground/80">Order Amount</span>
              <span className="font-bold">₵{order.price}</span>
            </div>
            <div className="flex justify-between border-t border-primary-foreground/20 pt-4">
              <span className="text-primary-foreground/80">Commission (10%)</span>
              <span className="font-bold">-₵{(order.price * 0.1).toFixed(2)}</span>
            </div>
            <div className="flex justify-between border-t border-primary-foreground/20 pt-4">
              <span className="font-bold">Your Payout</span>
              <span className="text-xl font-bold">₵{(order.price * 0.9).toFixed(2)}</span>
            </div>

            <div className="bg-primary-foreground/10 p-3 rounded-lg mt-4 text-sm">
              <p className="font-medium mb-1">Payment Status</p>
              <p className="text-primary-foreground/80 text-xs">
                Funds will be released to your Mobile Money account once the buyer confirms delivery.
              </p>
            </div>

            <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground mt-4">Contact Buyer</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
