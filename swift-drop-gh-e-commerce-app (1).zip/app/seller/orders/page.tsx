"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Check, Truck, Package } from "lucide-react"

export default function OrdersPage() {
  const orders = [
    {
      id: 1001,
      buyer: "John Doe",
      product: "Premium Wireless Headphones",
      amount: 299.99,
      date: "2025-12-02",
      status: "pending",
      location: "Accra",
    },
    {
      id: 1002,
      buyer: "Jane Smith",
      product: "USB-C Cable",
      amount: 19.99,
      date: "2025-12-01",
      status: "shipped",
      location: "Kumasi",
    },
    {
      id: 1003,
      buyer: "Bob Wilson",
      product: "Laptop Stand",
      amount: 79.99,
      date: "2025-11-30",
      status: "delivered",
      location: "Tema",
    },
    {
      id: 1004,
      buyer: "Alice Brown",
      product: "Premium Wireless Headphones",
      amount: 299.99,
      date: "2025-11-28",
      status: "pending_confirmation",
      location: "Sekondi",
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "shipped":
        return "bg-blue-100 text-blue-800"
      case "delivered":
        return "bg-green-100 text-green-800"
      case "pending_confirmation":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <ShoppingCart className="w-4 h-4" />
      case "shipped":
        return <Truck className="w-4 h-4" />
      case "delivered":
        return <Check className="w-4 h-4" />
      case "pending_confirmation":
        return <Package className="w-4 h-4" />
      default:
        return null
    }
  }

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Order Management</h1>

      {/* Orders Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Orders</CardTitle>
          <CardDescription>Track and manage all incoming orders</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold">Order ID</th>
                  <th className="text-left py-3 px-4 font-semibold">Buyer</th>
                  <th className="text-left py-3 px-4 font-semibold">Product</th>
                  <th className="text-left py-3 px-4 font-semibold">Amount</th>
                  <th className="text-left py-3 px-4 font-semibold">Location</th>
                  <th className="text-left py-3 px-4 font-semibold">Date</th>
                  <th className="text-left py-3 px-4 font-semibold">Status</th>
                  <th className="text-left py-3 px-4 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id} className="border-b border-border hover:bg-muted/50">
                    <td className="py-3 px-4 font-bold">#{order.id}</td>
                    <td className="py-3 px-4">{order.buyer}</td>
                    <td className="py-3 px-4">{order.product}</td>
                    <td className="py-3 px-4 font-bold text-accent">₵{order.amount}</td>
                    <td className="py-3 px-4">{order.location}</td>
                    <td className="py-3 px-4 text-sm">{order.date}</td>
                    <td className="py-3 px-4">
                      <Badge className={`flex items-center gap-1 w-fit ${getStatusColor(order.status)}`}>
                        {getStatusIcon(order.status)}
                        {order.status.replace(/_/g, " ").charAt(0).toUpperCase() +
                          order.status.replace(/_/g, " ").slice(1)}
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      <Button size="sm" className="bg-accent hover:bg-accent/90 text-accent-foreground text-xs">
                        View Details
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Order Status Flow */}
      <Card>
        <CardHeader>
          <CardTitle>Order Status Guide</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center gap-4">
              <ShoppingCart className="w-5 h-5 text-yellow-600" />
              <div>
                <p className="font-semibold">Pending</p>
                <p className="text-sm text-muted-foreground">Order received, ready to ship</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Truck className="w-5 h-5 text-blue-600" />
              <div>
                <p className="font-semibold">Shipped</p>
                <p className="text-sm text-muted-foreground">Item delivered to VIPEX parcel office</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Package className="w-5 h-5 text-purple-600" />
              <div>
                <p className="font-semibold">Pending Confirmation</p>
                <p className="text-sm text-muted-foreground">Awaiting buyer receipt confirmation</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Check className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-semibold">Delivered</p>
                <p className="text-sm text-muted-foreground">Buyer confirmed receipt, funds released</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
