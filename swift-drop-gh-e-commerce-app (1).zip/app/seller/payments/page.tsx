"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { DollarSign, CheckCircle, Clock } from "lucide-react"

export default function PaymentsPage() {
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Payment Management</h1>

      {/* Earnings Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Available for Payout</p>
                <p className="text-3xl font-bold text-accent">₵2,850.25</p>
              </div>
              <DollarSign className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">In Escrow</p>
                <p className="text-3xl font-bold">₵4,200.75</p>
              </div>
              <Clock className="w-10 h-10 text-yellow-600 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Paid Out</p>
                <p className="text-3xl font-bold">₵12,340.50</p>
              </div>
              <CheckCircle className="w-10 h-10 text-green-600 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payout Section */}
      <Card>
        <CardHeader>
          <CardTitle>Request Payout</CardTitle>
          <CardDescription>Transfer your available balance to your Mobile Money account</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-muted/50 p-4 rounded-lg">
            <p className="text-sm font-medium mb-2">Registered Mobile Money Account</p>
            <p className="text-lg font-bold">+233 50 123 4567</p>
          </div>
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground w-full">
            Request Payout of ₵2,850.25
          </Button>
        </CardContent>
      </Card>

      {/* Payment History */}
      <Card>
        <CardHeader>
          <CardTitle>Payment History</CardTitle>
          <CardDescription>Your transaction and payout records</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { date: "2025-12-01", type: "Payout", amount: "₵3,000.00", status: "completed", momoRef: "MPT123456" },
              { date: "2025-11-20", type: "Payout", amount: "₵2,500.00", status: "completed", momoRef: "MPT123457" },
              {
                date: "2025-11-10",
                type: "Order Settlement",
                amount: "₵150.00",
                status: "held_in_escrow",
                momoRef: "-",
              },
            ].map((payment, idx) => (
              <div key={idx} className="flex items-center justify-between pb-4 border-b border-border last:border-0">
                <div>
                  <p className="font-medium">{payment.type}</p>
                  <p className="text-sm text-muted-foreground">
                    {payment.date} • Ref: {payment.momoRef}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-accent">{payment.amount}</p>
                  <span
                    className={`text-xs px-2 py-1 rounded ${payment.status === "completed" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`}
                  >
                    {payment.status === "completed" ? "Completed" : "In Escrow"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
