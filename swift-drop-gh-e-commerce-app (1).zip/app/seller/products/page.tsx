"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Package, Edit, Trash2, Eye, Plus } from "lucide-react"

export default function ProductsPage() {
  const [showAddProduct, setShowAddProduct] = useState(false)

  const products = [
    {
      id: 1,
      name: "Premium Wireless Headphones",
      category: "Electronics",
      price: 299.99,
      stock: 45,
      views: 1240,
      sales: 32,
      status: "active",
    },
    {
      id: 2,
      name: "USB-C Cable",
      category: "Accessories",
      price: 19.99,
      stock: 120,
      views: 820,
      sales: 156,
      status: "active",
    },
    {
      id: 3,
      name: "Laptop Stand",
      category: "Office",
      price: 79.99,
      stock: 0,
      views: 560,
      sales: 12,
      status: "out_of_stock",
    },
  ]

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Product Inventory</h1>
        <Button
          onClick={() => setShowAddProduct(!showAddProduct)}
          className="bg-accent hover:bg-accent/90 text-accent-foreground"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Product
        </Button>
      </div>

      {/* Add Product Form */}
      {showAddProduct && (
        <Card>
          <CardHeader>
            <CardTitle>Add New Product</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Product Name *</Label>
                <Input id="name" placeholder="Enter product name" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <select id="category" className="w-full px-3 py-2 border border-border rounded-md bg-background">
                  <option>Electronics</option>
                  <option>Fashion</option>
                  <option>Books</option>
                  <option>Home & Garden</option>
                </select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="price">Price (₵) *</Label>
                <Input id="price" type="number" placeholder="0.00" min="0" step="0.01" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity in Stock *</Label>
                <Input id="quantity" type="number" placeholder="0" min="0" />
              </div>

              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="description">Product Description</Label>
                <textarea
                  id="description"
                  placeholder="Describe your product..."
                  className="w-full px-3 py-2 border border-border rounded-md bg-background"
                  rows={4}
                />
              </div>

              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="images">Product Images</Label>
                <Input id="images" type="file" multiple accept="image/*" />
              </div>

              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="tags">Tags (comma separated)</Label>
                <Input id="tags" placeholder="e.g., wireless, premium, best-seller" />
              </div>
            </div>

            <div className="flex gap-4 justify-end">
              <Button variant="outline" onClick={() => setShowAddProduct(false)}>
                Cancel
              </Button>
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">Create Product</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Products Table */}
      <Card>
        <CardHeader>
          <CardTitle>Your Products</CardTitle>
          <CardDescription>Manage and monitor your product listings</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold">Product</th>
                  <th className="text-left py-3 px-4 font-semibold">Price</th>
                  <th className="text-left py-3 px-4 font-semibold">Stock</th>
                  <th className="text-left py-3 px-4 font-semibold">Views</th>
                  <th className="text-left py-3 px-4 font-semibold">Sales</th>
                  <th className="text-left py-3 px-4 font-semibold">Status</th>
                  <th className="text-left py-3 px-4 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => (
                  <tr key={product.id} className="border-b border-border hover:bg-muted/50">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <Package className="w-5 h-5 text-muted-foreground" />
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-xs text-muted-foreground">{product.category}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-bold text-accent">₵{product.price}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-3 py-1 rounded-full text-sm ${product.stock > 0 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}
                      >
                        {product.stock}
                      </span>
                    </td>
                    <td className="py-3 px-4">{product.views}</td>
                    <td className="py-3 px-4">{product.sales}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${product.status === "active" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}`}
                      >
                        {product.status === "active" ? "Active" : "Out of Stock"}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <Button size="sm" variant="ghost">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-destructive">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
