"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function SellerProfilePage() {
  return (
    <div className="p-6 space-y-6 max-w-3xl">
      <div>
        <h1 className="text-3xl font-bold mb-2">Seller Profile</h1>
        <p className="text-muted-foreground">Manage your business information</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Business Information</CardTitle>
          <CardDescription>Your shop details</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="businessName">Business Name</Label>
              <Input id="businessName" placeholder="Your Business" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Input id="category" placeholder="Electronics" />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Business Description</Label>
            <textarea
              id="description"
              placeholder="Tell customers about your business..."
              className="w-full px-3 py-2 border border-border rounded-md bg-background"
              rows={4}
            />
          </div>
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">Save Changes</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Mobile Money Account</CardTitle>
          <CardDescription>Where payouts will be sent</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="momoNumber">Mobile Money Number</Label>
            <Input id="momoNumber" placeholder="+233 500 000 000" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="momoName">Account Name</Label>
            <Input id="momoName" placeholder="Name on account" />
          </div>
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">Update Account</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Shop Address</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input placeholder="Street Address" />
          <Input placeholder="City" />
          <Input placeholder="Region" />
          <Input placeholder="Postal Code" />
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">Update Address</Button>
        </CardContent>
      </Card>
    </div>
  )
}
