"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, DollarSign, ShoppingCart, Users } from "lucide-react"

export default function SalesPage() {
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Sales Analytics</h1>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Revenue</p>
                <p className="text-3xl font-bold text-accent">₵15,420</p>
                <p className="text-xs text-green-600 mt-2">+12% from last month</p>
              </div>
              <DollarSign className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Orders</p>
                <p className="text-3xl font-bold">287</p>
                <p className="text-xs text-green-600 mt-2">+8% from last month</p>
              </div>
              <ShoppingCart className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Unique Buyers</p>
                <p className="text-3xl font-bold">156</p>
                <p className="text-xs text-green-600 mt-2">+5% from last month</p>
              </div>
              <Users className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Avg. Order Value</p>
                <p className="text-3xl font-bold">₵53.72</p>
                <p className="text-xs text-green-600 mt-2">+3% from last month</p>
              </div>
              <TrendingUp className="w-10 h-10 text-accent opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Performing Products */}
      <Card>
        <CardHeader>
          <CardTitle>Top Performing Products</CardTitle>
          <CardDescription>Your best-selling items this month</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { product: "Premium Wireless Headphones", sales: 32, revenue: "₵9,596.68" },
              { product: "USB-C Cable", sales: 156, revenue: "₵3,118.44" },
              { product: "Laptop Stand", sales: 12, revenue: "₵959.88" },
            ].map((item, idx) => (
              <div key={idx} className="flex items-center justify-between pb-4 border-b border-border last:border-0">
                <div>
                  <p className="font-medium">{item.product}</p>
                  <p className="text-sm text-muted-foreground">{item.sales} sales</p>
                </div>
                <p className="font-bold text-accent">{item.revenue}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
