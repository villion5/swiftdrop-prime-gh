"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface CheckoutFormProps {
  productId: string
  productName: string
  sellerId: string
  quantity: number
  totalPrice: number
  buyerId: string
  onSuccess?: () => void
}

export function CheckoutForm({
  productId,
  productName,
  sellerId,
  quantity,
  totalPrice,
  buyerId,
  onSuccess,
}: CheckoutFormProps) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const handleCheckout = async () => {
    setError(null)
    setLoading(true)

    try {
      const response = await fetch("/api/wallet/purchase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          buyerId,
          sellerId,
          productId,
          quantity,
          totalPrice,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Purchase failed")
      }

      setSuccess(true)
      onSuccess?.()
    } catch (err) {
      setError(err instanceof Error ? err.message : "Purchase failed")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Order Summary</CardTitle>
        <CardDescription>Review and confirm your purchase</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="border-green-200 bg-green-50">
            <AlertDescription className="text-green-800">
              Order placed successfully! Your payment is secured in escrow.
            </AlertDescription>
          </Alert>
        )}

        <div className="space-y-3 border-b border-border pb-4">
          <div className="flex justify-between">
            <span className="text-muted-foreground">
              {productName} × {quantity}
            </span>
            <span className="font-medium">₵{totalPrice.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Subtotal</span>
            <span>₵{totalPrice.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Escrow Protection</span>
            <span className="text-green-600">Secured</span>
          </div>
        </div>

        <div className="bg-muted/50 p-3 rounded-lg">
          <p className="text-xs text-muted-foreground mb-2">Your payment is protected by:</p>
          <ul className="text-xs space-y-1 text-muted-foreground">
            <li>✓ 10% Commission held for platform services</li>
            <li>✓ Funds released upon your confirmation</li>
            <li>✓ Full refund if you don't receive items</li>
          </ul>
        </div>

        <Button
          onClick={handleCheckout}
          disabled={loading}
          className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            `Purchase for ₵${totalPrice.toFixed(2)}`
          )}
        </Button>

        <p className="text-xs text-center text-muted-foreground">
          By purchasing, you agree to our terms and escrow protection policy
        </p>
      </CardContent>
    </Card>
  )
}
