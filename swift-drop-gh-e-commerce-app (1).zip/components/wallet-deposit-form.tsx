"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { AlertCircle, Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface WalletDepositFormProps {
  userId: string
  onSuccess?: () => void
}

export function WalletDepositForm({ userId, onSuccess }: WalletDepositFormProps) {
  const [amount, setAmount] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const handleDeposit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSuccess(false)
    setLoading(true)

    try {
      const depositAmount = Number.parseFloat(amount)
      if (!depositAmount || depositAmount <= 0) {
        throw new Error("Please enter a valid amount")
      }

      // In production, integrate with Stripe card element
      // This is a simplified example
      const response = await fetch("/api/wallet/deposit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          amount: depositAmount,
          paymentMethodId: "pm_card_visa", // Replace with actual payment method from card element
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Deposit failed")
      }

      setSuccess(true)
      setAmount("")
      onSuccess?.()

      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Deposit failed")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Top Up Your Wallet</CardTitle>
        <CardDescription>Add funds to your SwiftDrop wallet for seamless purchases</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="border-green-200 bg-green-50">
            <AlertDescription className="text-green-800">
              Deposit successful! Your wallet has been updated.
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleDeposit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="amount">Deposit Amount (₵)</Label>
            <Input
              id="amount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min="1"
              step="0.01"
              disabled={loading}
            />
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[50, 100, 500].map((preset) => (
              <Button
                key={preset}
                type="button"
                variant="outline"
                onClick={() => setAmount(preset.toString())}
                disabled={loading}
                className="border-border hover:border-accent"
              >
                ₵{preset}
              </Button>
            ))}
          </div>

          <Button
            type="submit"
            disabled={loading || !amount}
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              "Deposit to Wallet"
            )}
          </Button>
        </form>

        <div className="text-xs text-muted-foreground space-y-1">
          <p>Payment processed securely via Stripe</p>
          <p>Instant wallet credit upon successful payment</p>
        </div>
      </CardContent>
    </Card>
  )
}
