import { createClient } from "@supabase/supabase-js"

let instance: ReturnType<typeof createClient> | undefined

function getSupabaseClient() {
  if (instance) return instance

  instance = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)

  return instance
}

export const supabase = getSupabaseClient()
