import { createClient } from "@supabase/supabase-js"

let instance: ReturnType<typeof createClient> | undefined

function getSupabaseServer() {
  if (instance) return instance

  instance = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

  return instance
}

export const supabaseServer = getSupabaseServer()
